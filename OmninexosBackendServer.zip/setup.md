 **Setup → Docker → Redis → Memory → Database → Git → Project → Node/TS → Telegram → OAuth**.


---

### **System & Environment Setup**
sudo timedatectl set-timezone Africa/Johannesburg

```bash
sudo apt update
sudo apt upgrade
sudo apt install git
sudo apt-get install docker.io
sudo systemctl start docker
sudo systemctl enable docker
sudo apt install docker-compose
sudo apt install docker-buildx
docker --version
docker-compose --version
sudo systemctl restart docker
chmod +x deploy.sh
./deploy.sh
```
---

### **Docker Commands**

```bash
# Build and start containers
sudo docker-compose -f docker-compose.prod.yml up --build -d
sudo docker-compose -f docker-compose.dev.yml up --build -d

# Stop containers
sudo docker-compose down --remove-orphans

# Remove all unused volumes, networks, dangling containers, images
sudo docker system prune -a --volumes
```

---

### **Redis**

```bash
# Flush all keys
redis-cli flushall

# Set value in cache using container id
sudo docker exec -it 0d5713f7abef redis-cli
SET message "paused"

# Verify value
GET openTime
```

---

### **Memory & System Tweaks**

```bash
sudo sysctl -w vm.overcommit_memory=1
```

---

### **Database**

```bash
# Connect using pgcli
pgcli postgresql://postgres:1234@localhost:5432/postgres

# Connect using docker
sudo docker exec -it ace39ed6a7c9 psql -h 41.72.145.2 -U masskg -d postgres -p 7704
```

---

### **Git**

```bash
# Override all local changes
git reset --hard
git pull

# Store credentials to avoid re-entering
git config --global credential.helper store

# Setting up new remote
git remote -v
git remote remove origin
git remote add origin https://github.com/OmniScience-Digital/OmniscienceBackendServer.git
git remote set-url origin https://github.com/OmniScience-Digital/StockControl.git
git remote set-url origin https://github.com/OmniScience-Digital/TelegramServer-V2.git

# Merge branches
git checkout main
git merge test --no-ff -m "Merge branch 'test' into main"
git pull https://OmniScience-Digital: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@


git config --global core.autocrlf true
```

**Git credentials & tokens**

```
Parent Email: techstack@omniscience.digital
Username: OmniScience-Digital
Git password: 0275.Omni.@digital
Token: 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
```

git credential-osxkeychain erase
host=github.com
protocol=https
---

git config --global user.name OmniScience-Digital
git config --global user.email techstack@omniscience.digital
git config --global core.autocrlf true

### **Aliases**

```bash
alias dcdev='docker-compose -f docker-compose.dev.yml up --build'
source ~/.zshrc  # or ~/.bashrc
# then run:
dcdev
```

---

### **Project Navigation**

```bash
tree -L 3
```

---

### **TypeScript / Node.js Tasks**

```bash
# Linting
npx eslint src --ext .ts

# Formatting
npx prettier --write src/

# Modify dist file extensions
npm install -D ts-add-js-extension
npx ts-add-js-extension --dir=dist
```


systemctl is-enabled docker